export const ADMIN = 'ADMIN';
